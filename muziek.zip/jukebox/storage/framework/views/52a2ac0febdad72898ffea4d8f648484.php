


<?php $__env->startSection('content'); ?>
<div class="admin-wrapper">
    <div class="admin-header">
        <h2 class="admin-title">Admin Paneel - Liedjesbeheer</h2>
        <div class="admin-actions">
            <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary">Publieke homepage</a>
            <a href="<?php echo e(route('songs.create')); ?>" class="btn btn-primary">Nieuw nummer</a>
        </div>
    </div>

    <?php if(session('success')): ?>
    <div class="alert-success" id="flash-message">
        <?php echo e(session('success')); ?>

    </div>

    <script>
        setTimeout(() => {
            const flash = document.getElementById('flash-message');
            if (flash) flash.style.display = 'none';
        }, 4000); // verdwijnt na 4 seconden
    </script>
    <?php endif; ?>

    <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="admin-song-card">
            <img src="<?php echo e(asset('storage/' . $song->cover_image)); ?>" alt="Cover" class="admin-song-cover">

            <div class="admin-song-info">
                <div>
                    <h3 class="admin-song-title"><?php echo e($song->title); ?></h3>
                    <p class="admin-song-artist"><?php echo e($song->artist); ?></p>
                    <p class="admin-song-plays">👁️ <?php echo e($song->plays); ?>x afgespeeld</p>
                </div>

                <div class="admin-song-actions-column">
                    <a href="<?php echo e(route('songs.edit', $song)); ?>" class="btn btn-blue">Bewerk</a>
                    <form action="<?php echo e(route('songs.destroy', $song)); ?>" method="POST" onsubmit="return confirm('Weet je zeker dat je dit nummer wilt verwijderen?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-red">Verwijder</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\lol\Documents\090006_examen\090006-Examen-Jukebox\jukebox\resources\views/jukebox/admin-index.blade.php ENDPATH**/ ?>
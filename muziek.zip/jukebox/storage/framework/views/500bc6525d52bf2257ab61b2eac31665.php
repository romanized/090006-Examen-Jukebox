

<?php $__env->startSection('content'); ?>
<div class="form-wrapper">
    <div class="form-header">
        <h2>Nieuw nummer toevoegen</h2>
        <a href="<?php echo e(route('songs.admin')); ?>" class="form-btn form-btn-secondary">← Terug naar dashboard</a>
    </div>


    <?php if($errors->any()): ?>
        <div class="alert-box">
            <ul class="list-disc pl-5 space-y-1">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-sm"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('songs.store')); ?>" method="POST" enctype="multipart/form-data" class="form-panel">
        <?php echo csrf_field(); ?>

        <label>Titel</label>
        <input type="text" name="title" required>

        <label>Artiest</label>
        <input type="text" name="artist" required>

        <label>MP3-bestand</label>
        <input type="file" name="filename" accept=".mp3" required>

        <label>Cover afbeelding</label>
        <input type="file" name="cover_image" accept="image/*" required>

        <button type="submit" class="btn btn-primary">Toevoegen</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\lol\Documents\090006_examen\090006-Examen-Jukebox\jukebox\resources\views/jukebox/create.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>The Hatchet</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body>

<header>
    <div class="container flex-between">
        <a href="<?php echo e(route('home')); ?>" class="logo">🎧 The Hatchet Jukebox</a>

        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('songs.create')); ?>" class="btn">Nieuw nummer toevoegen</a>
        <?php endif; ?>
    </div>
</header>

<main class="container">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH C:\Users\lol\Documents\090006_examen\090006-Examen-Jukebox\jukebox\resources\views/layouts/app-layout.blade.php ENDPATH**/ ?>
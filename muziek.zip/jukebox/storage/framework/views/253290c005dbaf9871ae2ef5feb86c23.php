

<?php $__env->startSection('content'); ?>
<div class="form-wrapper">
    <div class="form-header">
        <h2>Bewerk nummer</h2>
        <a href="<?php echo e(route('songs.admin')); ?>" class="form-btn form-btn-secondary">← Terug naar dashboard</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert-box">
            <ul class="list-disc pl-5 space-y-1">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-sm"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('songs.update', $song)); ?>" method="POST" enctype="multipart/form-data" class="form-panel">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label>Titel</label>
        <input type="text" name="title" value="<?php echo e(old('title', $song->title)); ?>">

        <label>Artiest</label>
        <input type="text" name="artist" value="<?php echo e(old('artist', $song->artist)); ?>">

        <label>Nieuwe MP3 (optioneel)</label>
        <input type="file" name="filename" accept=".mp3">

        <label>Nieuwe Cover (optioneel)</label>
        <input type="file" name="cover_image" accept="image/*">

        <p class="text-sm text-gray-600 mt-2">Aantal keer gekozen: <strong><?php echo e($song->plays); ?></strong></p>

        <button type="submit" class="btn btn-primary">Opslaan</button>
    </form>

    <?php if($song->reviews->count()): ?>
        <div class="review-list">
            <h3>Reviews</h3>
            <ul>
                <?php $__currentLoopData = $song->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        "<?php echo e($review->review); ?>"
                        <form action="<?php echo e(route('songs.reviews.destroy', [$song, $review])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:underline">Verwijder</button>
                        </form>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\lol\Documents\090006_examen\090006-Examen-Jukebox\jukebox\resources\views/jukebox/edit.blade.php ENDPATH**/ ?>
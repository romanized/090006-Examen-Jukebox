<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Tailwind Test</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-900 text-white h-screen flex items-center justify-center">
    <div class="text-center space-y-4">
        <h1 class="text-4xl font-bold text-pink-500">Tailwind werkt</h1>
        <p class="text-lg text-gray-300">Als je dit ziet, is Tailwind goed geconfigureerd ✅</p>
    </div>
</body>
</html>
<?php /**PATH C:\Users\lol\Documents\090006_examen\090006-Examen-Jukebox\jukebox\resources\views/test-tailwind.blade.php ENDPATH**/ ?>